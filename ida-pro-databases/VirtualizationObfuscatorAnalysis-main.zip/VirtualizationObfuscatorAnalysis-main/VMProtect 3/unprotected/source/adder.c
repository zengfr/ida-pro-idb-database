int adder(int x, int y) {
	return x + y;
}

int main(int argc, int** argv) {
	adder(20, 40);
	return 0;
}