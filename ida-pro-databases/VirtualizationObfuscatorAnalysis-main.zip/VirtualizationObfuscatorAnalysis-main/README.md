# VirtualizationObfuscatorAnalysis
A repository of IDA Databases and Binaries used for analysis of popular commercial virtual-machine obfuscators.
These binaries and plugins were used to create blog posts on both [VMProtect 3](https://www.mitchellzakocs.com/blog/vmprotect3) and [Tigress](https://www.mitchellzakocs.com/blog/tigress).